﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using TASK_1.Models;

namespace TASK_1.Controllers;


public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        var i = new TASK_1.Models.Index();
        i.name = "MD. TOUKIR AHMED";
        i.id = "21-45214-2";
        i.email = "toukerahmed.2728@gmail.com";
        i.github = "https://github.com/TUHIN27289";
        i.profile = "https://github.com/TUHIN27289";
        ViewBag.i = new TASK_1.Models.Index[] { i };
        return View();
    }

    public IActionResult Privacy()
    {

        return View();
    }

    public IActionResult Education()
    {
        var e = new Education();
        e.degree = " BSC";
        e.year = "  2025";
        e.instution = "AIUB";
        ViewBag.e = new TASK_1.Models.Education[] { e };


        return View();
    }

    public IActionResult Project()
    {
        var pr = new Project();
        pr.courseName = "Computer Graphics";
        pr.title = "Interactive OpenGL Graphics Project";
        pr.description = "The Campsite Management System is a desktop application that is designed to " +
            "help campsite managers and administrators to " +
            "manage their camping grounds more efficiently. The system will provide users with a" +
            " centralized platform where they can manage everything from reservations to " +
            "facilities management.administrators" +
            "<p> <a href='https://github.com/TUHIN27289/AIUB_CS_Computer_Graphics'>Click here to visit</a></p>";

        var pr1 = new Project();

        pr1.courseName = "Java";
        pr1.title = "Java Hospital Management System Project";
        pr1.description = "The repository on GitHub contains Java source code files" +
            " for a hospital management system, encompassing various " +
            "functionalities such as ambulance management, canteen management, " +
            "doctor interfaces, emergency handling, hospital management, " +
            "lab reports, medication management, patient information, " +
            "staff management, and more. The commit history suggests " +
            "ongoing development and contributions. To add new files to the " +
            "repository, one can follow the standard procedure of creating " +
            "a new repository on GitHub, cloning it locally, copying " +
            "the Java files into the local repository, adding and committing " +
            "the changes, and finally pushing the changes back to " +
            "the GitHub repository. This approach allows for version control," +
            " collaboration, and easy tracking of changes in the healthcare " +
            "application's codebase. " +
            "<br><br> <a href='https://github.com/TUHIN27289/AIUB_CS_Java-project'>Click here to visit</a>";



        var pr2 = new Project();

        pr2.courseName = "C#";
        pr2.title = "Campsite Management System";
        pr2.description = "The Campsite Management System is a desktop application that is designed to help campsite managers and administrators to manage their camping grounds more efficiently. The system will provide users with a centralized platform where they can manage everything from reservations to facilities management." +
            "<br><br> <a href='https://github.com/TUHIN27289/AIUB-CS-PROJECT'>Click here to visit</a>";



        var pr3 = new Project();
        pr3.courseName = "Deep Learning";
        pr3.title = "Python AI Assistant";
        pr3.description = "The provided Python script is an interactive voice-controlled " +
            "assistant that can perform various tasks. It uses speech recognition and text-to-speech " +
            "synthesis to interact with the user." + "<br><br> <a href = 'https://github.com/TUHIN27289/AIUB_CS_Python_AI_Assistant' > Click here to visit </a> ";


        //var pr4 = new Project();
        //pr4.courseName = "Deep Learning";
        //pr4.title = "Python Brain Tumor Detection";
        //pr4.description = "This Python script is a Brain Tumor Detection web application that uses a convolutional neural network (CNN) trained on medical images to classify brain tumor images into two categories: "+"No Brain Tumor" + "and"+ "Yes Brain Tumor." +"The application is built using Flask and allows users to upload MRI or CT scan images of the brain for real-time tumor detection." + "<br><br> <a href = 'https://github.com/TUHIN27289/AIUB_CS_Python_Brain_Tumor_Detection' > Click here to visit </a> ";

        var pr4 = new Project();
        pr4.courseName = "Deep Learning";
        pr4.title = "Python Brain Tumor Detection";
        pr4.description = "This Python script is a Brain Tumor Detection web application that uses a convolutional neural network (CNN) trained on medical images to classify brain tumor images into two categories: \"No Brain Tumor\" and \"Yes Brain Tumor.\" The application is built using Flask and allows users to upload MRI or CT scan images of the brain for real-time tumor detection.<br><br><a href='https://github.com/TUHIN27289/AIUB_CS_Python_Brain_Tumor_Detection'>Click here to visit</a>";


        ViewBag.prr = new TASK_1.Models.Project[] { pr,pr1,pr2,pr3,pr4 };


        return View();
    }

    public IActionResult Personal()
    {
        var p = new Personal();
        p.name = "MD.TOUKIR AHMED";
        p.fname = "MD.AZIZAR RAHMAN";
        p.mname = "MST SHORIFA YEASMIN";
        p.religion = "Islam";
        p.nationality = "Bangladeshi";
        p.age = "30";
        p.presentAddress = "khuril,kazibzri,kha-119";
        p.parmanentAddress = "Birampur,Dinajpur,Bangladesh\n";
        ViewBag.p = new TASK_1.Models.Personal[] { p };

        return View();
    }

    public IActionResult Reference()
    {
        var r = new Reference();
        r.name = "MD AZIZAR RAHMAN";
        r.title = "CEO Of ABC Software Limited";
        r.companyName = "ABC Software Limited";
        r.email = "toukerahmed.2728@gmail.com";
        r.phone = "0179095XXXX";
        ViewBag.r = new TASK_1.Models.Reference[] { r };

         return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

