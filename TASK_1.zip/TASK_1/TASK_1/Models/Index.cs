﻿using System;
namespace TASK_1.Models
{
	public class Index
	{
		public string name;
        public string id;
        public string email;
        public string github;
        public string profile;

    }
}

