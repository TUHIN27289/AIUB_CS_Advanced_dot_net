﻿using System;
namespace TASK_1.Models
{
	public class Education
	{
        public string degree;
        public string year;
        public string instution;
    }
}

