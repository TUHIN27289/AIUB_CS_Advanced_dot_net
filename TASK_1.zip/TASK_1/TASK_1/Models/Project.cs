﻿using System;
namespace TASK_1.Models
{
	public class Project
	{
        public string courseName;
        public string title;
        public string description;
    }
}

