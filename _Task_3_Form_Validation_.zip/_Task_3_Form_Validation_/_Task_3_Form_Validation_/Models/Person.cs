﻿using _Task_3_Form_Validation_.Annotation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
namespace _Task_3_Form_Validation_.Models
{
    public class Person
    {
        [Required]
        [ValidateName(ErrorMessage ="Name can contain only alphabet and space BUT number and special character is not allowed")]
        [StringLength(100,MinimumLength =8)]
        public string Name { get; set; }

        
        [ValidateUserName(ErrorMessage ="Username cannot be more than 10 letter and space is not allowed")]
        [StringLength(6, MinimumLength = 3)]
        [Required]
        public string Username { get; set; }
        [Required]
        [ValidateID(ErrorMessage ="")]
        public string ID { get; set; }

        [Required]
        [ValidateEmail]
        public string Email { get; set; }
        [Required]
        public string Gender { get; set; }
        [Required]
        public string Profession { get; set; }
        [Required]
        [Range(1,40)]
        public int Roll { get; set; }

        [Required]
        public string[] Hobbies { get; set; }
    }
}
