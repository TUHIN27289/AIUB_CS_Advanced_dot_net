using _Task_3_Form_Validation_.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace _Task_3_Form_Validation_.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        [HttpGet]
        public IActionResult Index()
        {

            return View(new Person());
            //return View(new Person());  
        }
        [HttpPost]
        public IActionResult Index(Person p)
        {
            if (ModelState.IsValid) 
            {
                return RedirectToAction("Privacy");
            
            }
            return View(p); 
        
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
