﻿using System.ComponentModel.DataAnnotations;

namespace _Task_3_Form_Validation_.Annotation
{
    public class ValidateID : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != null)
            {
                string userID = value.ToString();

                // Check the length of the user ID
                if (userID.Length != 10)
                {
                    return new ValidationResult("User ID length must be 10 characters.");
                }

                // Extracting parts of the user ID
                string firstPart = userID.Substring(0, 2);
                string middlePart = userID.Substring(3, 5);
                string lastPart = userID.Substring(9, 1);

                // Parsing parts to integers for range check
                int firstPartValue, middlePartValue, lastPartValue;
                if (!int.TryParse(firstPart, out firstPartValue) ||
                    !int.TryParse(middlePart, out middlePartValue) ||
                    !int.TryParse(lastPart, out lastPartValue))
                {
                    return new ValidationResult("Invalid characters in user ID.");
                }

                // Check ranges
                if (firstPartValue < 0 || firstPartValue > 99)
                {
                    return new ValidationResult("First two digits must be in the range 00 to 99.");
                }

                if (middlePartValue < 0 || middlePartValue > 99999)
                {
                    return new ValidationResult("Middle five digits must be in the range 00000 to 99999.");
                }

                // Last part should be a single digit within the range 1 to 3
                if (lastPartValue < 1 || lastPartValue > 3)
                {
                    return new ValidationResult("Last digit must be a single digit between 1 and 3.");
                }
            }

            // Default success
            return ValidationResult.Success;
        }
    }
}
