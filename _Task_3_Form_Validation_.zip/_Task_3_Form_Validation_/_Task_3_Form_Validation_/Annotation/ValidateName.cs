﻿using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace _Task_3_Form_Validation_.Annotation
{
    public class ValidateName : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            // Check if value is null
            if (value == null)
            {
                // If value is null, consider it as invalid
                return false;
            }


            var Name = (string)value;
            // Convert the value to string and trim any leading or trailing spaces
            //var Name = value.ToString().Trim();

            // Check if the name contains only alphabets, spaces, and hyphens
            if (!Regex.IsMatch(Name, @"^[a-zA-Z\s-]+$"))
            {
                // If the name contains any characters other than alphabets, spaces, or hyphens, it's invalid
                return false;
            }

            // Additional validation: Ensure there are no consecutive spaces
            if (Name.Contains("  "))
            {
                // If there are consecutive spaces, it's invalid
                return false;
            }

            // The name is considered valid if it passes all the conditions
            return true;
        }
    }
}
