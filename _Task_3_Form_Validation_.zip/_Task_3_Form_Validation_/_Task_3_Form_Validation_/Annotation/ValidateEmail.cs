﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace _Task_3_Form_Validation_.Annotation
{
    public class ValidateEmail : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != null)
            {
                string email = value.ToString();

                // Regular expression pattern for email validation
                string pattern = @"^(\d{2}-\d{5}-\d)@student.aiub.edu$";

                // Check if the email matches the pattern
                Match match = Regex.Match(email, pattern);
                if (!match.Success)
                {
                    return new ValidationResult("Invalid email format. The email format should be xx-xxxxx-x@student.aiub.edu.");
                }

                // Extract ID portion from the matched email pattern
                string idFromEmail = match.Groups[1].Value;

                // Retrieve the ID field value from the model
                var idProperty = validationContext.ObjectType.GetProperty("ID");
                if (idProperty != null)
                {
                    var idValue = idProperty.GetValue(validationContext.ObjectInstance, null).ToString();

                    // Compare ID from email with the ID field value
                    if (!string.Equals(idFromEmail, idValue))
                    {
                        return new ValidationResult("The ID portion in the email does not match the ID field value.");
                    }
                }
            }

            // Default success
            return ValidationResult.Success;
        }
    }
}
