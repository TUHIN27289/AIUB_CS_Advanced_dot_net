﻿using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace _Task_3_Form_Validation_.Annotation
{
    public class ValidateUserName: ValidationAttribute
    {
        public override bool IsValid(object value)
        {

            // Check if value is null
            if (value == null)
            {
                // If value is null, consider it as invalid
                return false;
            }

            var UserName =(string)value;
            // Check if the username contains only alphabets, numbers, and special characters
            if (!Regex.IsMatch(UserName, @"^[a-zA-Z0-9\W]+$"))
            {
                // If the username contains any characters other than alphabets, numbers, or special characters, it's invalid
                return false;
            }

            // Check if the username contains spaces
            if (UserName.Contains(" "))
            {
                // If the username contains spaces, it's invalid
                return false;
            }

            // The username is considered valid if it passes all the conditions
            return true;
        }
    }
}
