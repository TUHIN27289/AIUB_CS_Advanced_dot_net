﻿using System;
namespace TASK_1.Models
{
	public class Privacy
	{
		public Privacy()
		{
		}
	}
}

